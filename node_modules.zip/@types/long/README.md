# Installation
> `npm install --save @types/long`

# Summary
This package contains type definitions for long.js (https://github.com/dcodeIO/long.js).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/long.

### Additional Details
 * Last updated: Wed, 22 Jan 2020 19:19:46 GMT
 * Dependencies: none
 * Global values: `Long`

# Credits
These definitions were written by Peter Kooijmans (https://github.com/peterkooijmans).
