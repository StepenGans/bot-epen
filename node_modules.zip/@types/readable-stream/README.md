# Installation
> `npm install --save @types/readable-stream`

# Summary
This package contains type definitions for readable-stream (https://github.com/nodejs/readable-stream).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/readable-stream.

### Additional Details
 * Last updated: Fri, 10 Jul 2020 15:37:57 GMT
 * Dependencies: [@types/safe-buffer](https://npmjs.com/package/@types/safe-buffer), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: `_Readable`

# Credits
These definitions were written by [TeamworkGuy2](https://github.com/TeamworkGuy2), and [markdreyer](https://github.com/markdreyer).
